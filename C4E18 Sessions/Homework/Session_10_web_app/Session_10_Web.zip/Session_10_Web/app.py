from flask import *
import mlab 

from models.service import Service
# from mongoengine import *
app = Flask(__name__)

#0. Create connection
mlab.connect()

new_service = Service(
    name = "Dat 100",
    dob = 1996,
    gender = 1,
    height = 174,
    phone = "012345887900",
    address = "Tran Duy Hung",
    status = False
)
new_service.save()



@app.route('/')
def index():
    return render_template('index.html')


@app.route('/admin')
def admin():
    all_service = Service.objects()
    return render_template("index.html", all_service = all_service)
    # return render_template("admin.html")

@app.route("/delete/<service_id>")
def delete(service_id):
    service_to_del = Service.objects().with_id(service_id)
    #  = al/l_service.objects().with_id(service_id)
    if service_to_del is None:
        return "Service not found"
    else:
        service_to_del.delete()
        return redirect(url_for("admin"))

    return "delete " + service_id

@app.route("/new-service",methods = ["GET","POST"]) 
def create():
    if request.method == "GET":
        return render_template("new_service.html")
    elif request.method == "POST":
        form = request.form
        name= form["name"]
        dob = form["dob"]
        address = form["dia chi"]
        # return "Posted"
        new_service = Service(
            name = name,
            dob = dob,
            address = address
        )   
        new_service.save()
        return redirect(url_for("admin"))



if __name__ == '__main__':
  app.run(debug=True)
 
